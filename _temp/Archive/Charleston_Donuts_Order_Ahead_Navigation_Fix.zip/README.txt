Charleston Donuts — Order Ahead Navigation Fix
================================================

Purpose
-------
Make every Order Ahead navigation link open the working interactive order page:

    order.html

Files updated
-------------
- rewards.html
- reviews.html
- menu.html
- index.html
- gallery.html
- contact.html
- coffee.html
- catering.html
- cakes-events.html
- about.html
- wv-favorites.html
- today.html

What changed
------------
- Links using index.html#order-ahead now point to order.html.
- The Home-page link using #order-ahead now points to order.html.
- No ordering logic, prices, Formspree settings, CSS, JavaScript, or menu data were changed.

Deployment
----------
1. Save this ZIP in Charleston-Donuts/_temp/ChatGPT.
2. Open the ZIP file.
3. Open Build_Files.
4. Copy all HTML files into the root of the Charleston-Donuts repository.
5. Choose Replace when Windows asks.
6. Test each page with Live Server:
   - Home
   - Menu
   - Catering
   - Sweet Rewards
   - Our Story
   - Gallery
   - Contact/Visit Us
   - Reviews
   - Today
   - WV Favorites
7. From each page, click Order Ahead and confirm it opens the interactive order.html page.
8. Review changes in GitHub Desktop.
9. Commit and push only after testing succeeds.

No files inside _temp should appear in GitHub Desktop because _temp/ is ignored.
